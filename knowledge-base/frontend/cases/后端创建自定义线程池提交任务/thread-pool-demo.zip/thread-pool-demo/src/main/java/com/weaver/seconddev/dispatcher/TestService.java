/**
 * 业务服务示例类
 *
 * <p>演示如何通过线程池提交异步任务，包含租户上下文传递的最佳实践。</p>
 *
 * @author
 * @version 1.0
 */
package com.weaver.seconddev.dispatcher;

import com.weaver.framework.rpc.context.impl.TenantRpcContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class TestService {

    private static final Logger log = LoggerFactory.getLogger(TestService.class);

    /**
     * 异步任务处理示例方法
     *
     * <p>典型调用场景：Controller接收请求后调用此方法进行异步处理</p>
     *
     * @param args 命令行参数（当前示例未实际使用）
     * @implNote 重要实现细节：
     * <ol>
     *   <li>通过静态方法获取线程池实例提交任务</li>
     *   <li>在异步线程中设置租户上下文（需确保后续清理）</li>
     *   <li>使用CallerRunsPolicy时需注意可能的主线程阻塞问题</li>
     * </ol>
     */
    public void test(String[] args) {
        String tenantKey = ""; // 应通过参数传入实际租户标识
        SecondevTaskDispatcher.getEcodeExecutor().execute(() -> {
            log.info("Async task started: processing data...");
            try {
                // 设置当前线程的租户上下文（需确保finally块中清理）
                TenantRpcContext.setTargetTenantKey(tenantKey);

                // 模拟业务操作（实际应替换为真实业务逻辑）
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                log.warn("Task execution interrupted", e);
            } catch (RuntimeException e) {
                // 捕获运行时异常并记录错误详情
                log.error("Business logic runtime exception", e);
            } catch (Exception e) {
                // 兜底异常处理（确保不出现未捕获异常）
                log.error("Unexpected exception occurred", e);
            } finally {
                /*
                 * 清理操作：
                 * 必须清除线程局部变量，避免内存泄漏和上下文污染
                 */
            }
            log.info("Async task ends.");
        });
    }
}