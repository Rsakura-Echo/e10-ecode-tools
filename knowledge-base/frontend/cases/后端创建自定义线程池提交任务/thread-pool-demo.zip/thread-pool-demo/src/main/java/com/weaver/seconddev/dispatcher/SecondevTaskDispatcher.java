/**
 * 线程池任务调度器
 *
 * <p>负责创建和管理业务数据处理专用的线程池实例，提供全局访问入口。</p>
 *
 * @author
 * @version 1.0
 * @since 2023-09-20
 */
package com.weaver.seconddev.dispatcher;

import com.weaver.common.threadPool.ThreadPoolUtil;
import com.weaver.common.threadPool.constant.RunModeConstant;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;

public class SecondevTaskDispatcher {
    /**
     * 线程池名称（用于监控识别）
     * @see ThreadPoolUtil#getPool 通过名称标识不同业务线程池
     */
    private static final String POOL_NAME = "secondev-data-process";

    /**
     * 核心线程数（长期保留的线程数量）
     * @value 默认值 4，建议通过配置中心动态调整
     */
    private static final int CORE_POOL_SIZE = 4;

    /**
     * 最大线程数（突发流量时允许扩展的线程上限）
     * @value 默认值 10，建议根据压测结果调整
     */
    private static final int MAX_POOL_SIZE = 10;

    /**
     * 业务数据处理线程池实例
     *
     * <p>线程池参数说明：</p>
     * <ul>
     *   <li>keepAliveTime: 30秒（非核心线程空闲存活时间）</li>
     *   <li>queueCapacity: 200（队列最大容量）</li>
     *   <li>runMode: ArrayBlockingQueue（有界队列保证资源可控）</li>
     *   <li>拒绝策略: CallerRunsPolicy（队列满时由提交线程直接执行）</li>
     * </ul>
     * @warning 需确保应用关闭时调用shutdown()释放资源
     */
    private static final ExecutorService SECONDEV_EXECUTOR = ThreadPoolUtil.getPool(
            POOL_NAME, CORE_POOL_SIZE, MAX_POOL_SIZE, 30, 200,
            RunModeConstant.ABQUEUE, new ThreadPoolExecutor.CallerRunsPolicy()
    );

    /**
     * 获取业务数据处理器线程池实例
     *
     * @return 全局唯一的线程池实例，用于执行异步数据处理任务
     * @note 方法名建议改为 getExecutor() 以提高可读性（当前名称存在拼写歧义）
     */
    public static ExecutorService getEcodeExecutor() {
        return SECONDEV_EXECUTOR;
    }
}