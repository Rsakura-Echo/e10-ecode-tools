package com.weaver.seconddev.cache.service;

import com.weaver.common.cache.base.BaseCache;
import com.weaver.common.cache.base.ModuleCacheInterface;
import com.weaver.seconddev.cache.cons.SecDemoModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

@Service
public class TestWorkflowCacheKey implements ModuleCacheInterface {

    @Autowired
    private BaseCache baseCache;

    @PostConstruct
    @Override
    public void register() throws IllegalAccessException {
        /**
         * 第一个参数是规范中约定的微服务的模块名称，如流程模块
         * 第二个参数是当前类名，用this.getClass()即可
         **/
        baseCache.register(SecDemoModule.MODULE, this.getClass());
    }

}
