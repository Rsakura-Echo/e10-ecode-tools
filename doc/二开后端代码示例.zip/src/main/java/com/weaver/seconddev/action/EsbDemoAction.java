package com.weaver.seconddev.action;

import cn.hutool.extra.spring.SpringUtil;
import com.weaver.common.base.entity.result.WeaResult;
import com.weaver.ebuilder.datasource.api.service.DataSetService;
import com.weaver.esb.api.rpc.EsbServerlessRpcRemoteInterface;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service("esbDemoAction")
public class EsbDemoAction implements EsbServerlessRpcRemoteInterface {

    private static final Logger log = LoggerFactory.getLogger(EsbDemoAction.class);

    @Override
    public WeaResult<Map<String, Object>> execute(Map<String, Object> params) {
        final DataSetService bean = SpringUtil.getBean(DataSetService.class);
        log.info("prams size is {}", params.size());
        params.put("extra", "abc");
        try {
            // todo
        } catch (Exception e) {
            log.error("error ", e);
        }
        return WeaResult.success();
    }
}
