package com.weaver.seconddev.cache.cons;

public interface SecDemoModule {

    // secondev
    public final static String MODULE = "SECONDEV_WORKFLOW";
    // 缓存key
    public final static String CACHE_KEY = "SEC_KEY";

}
