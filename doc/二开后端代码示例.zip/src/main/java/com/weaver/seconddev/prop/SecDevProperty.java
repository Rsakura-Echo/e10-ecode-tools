package com.weaver.seconddev.prop;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;


/**
 * @RefreshScope 若使用配置中心管理，则支持自动刷新同步
 * 二开服务配置文件：weaver-secondev-service.properties
 */
@Configuration
@RefreshScope
public class SecDevProperty {

    @Value("${weaver.secondev.custom.url}")
    private String moduleName;

    @Value("${weaver.secondev.custom.data:123}")
    private String customData;

    @Value("${weaver.secondev.custom.key:abc}")
    private String customKey;

    public String getModuleName() {
        return moduleName;
    }

    public String getCustomData() {
        return customData;
    }

    public String getCustomKey() {
        return customKey;
    }
}
