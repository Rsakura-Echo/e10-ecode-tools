package com.weaver.seconddev.secdev;

import cn.hutool.core.codec.Base64;
import cn.hutool.json.JSONUtil;
import com.weaver.datasource.utils.rest.CommonRestService;
import com.weaver.ebuilder.datasource.api.entity.ExecuteSqlEntity;
import com.weaver.ebuilder.datasource.api.enums.SourceType;
import com.weaver.framework.remote.client.rest.RestClient;
import com.weaver.framework.rpc.context.impl.TenantRpcContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service("datasource_test")
public class DataBaseService {

    private static final Logger log = LoggerFactory.getLogger(DataBaseService.class);

    @Autowired
    CommonRestService commonRestService;
    @Autowired
    private RestClient restClient;

    public static String base64(String sql) {
        return Base64.encode(sql);
    }

    /**
     * 根据数据库类型 找到对应数据库
     *
     * @param sourceType sourceType 枚举类
     *                   ETEAMS  :数据仓库
     *                   FORM: ebuilder表单
     *                   LOGIC: 各模块提供业务数据(逻辑表)
     *                   EXTERNAL： 外部数据源
     * @return
     */
    public Map<String, Object> getDataGroups(String sourceType) {
        try {
            //拼接参数
            MultiValueMap<String, Object> valueMap = new LinkedMultiValueMap<>();
            valueMap.add("sourceType", sourceType);
            //拼接请求头
            HttpHeaders requestHeaders = getHttpHeaders();
            List<MediaType> acceptTypes = new ArrayList<>();
            acceptTypes.add(MediaType.APPLICATION_JSON);
            requestHeaders.setAccept(acceptTypes);

            //form请求
            requestHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            return restClient.postForObject(requestHeaders, "/sapi/datasource/ds/group", valueMap, Map.class);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw e;

        }
    }


    /**
     * 执行服务内部sql
     * sourceType  :LOGIC
     * groupId  :   weaver-ebuilder-app-service
     * sql :      select * from ebda_app limit  10
     * 执行外部数据库sql
     * sourceType  :EXTERNAL
     * groupId  :   842668710322556928L 通过group接口获取数据加工内配置的连接id
     * sql :      select * from ebda_app limit  10
     *
     * @param
     * @return
     */
    public Map<String, Object> execute(String sourceType, String groupId, String sql) {
        //执行sql  参数sourceType   groupId  sql
        ExecuteSqlEntity executeSqlEntity = new ExecuteSqlEntity();
        executeSqlEntity.setSql(base64(sql));
        executeSqlEntity.setGroupId(groupId);
        executeSqlEntity.setSourceType(SourceType.valueOf(sourceType));

        //拼接参数
        MultiValueMap<String, Object> valueMap = new LinkedMultiValueMap<>();
        valueMap.add("params", JSONUtil.toJsonStr(executeSqlEntity));
        //拼接请求头
        HttpHeaders requestHeaders = getHttpHeaders();
        List<MediaType> acceptTypes = new ArrayList<>();
        acceptTypes.add(MediaType.APPLICATION_JSON);
        requestHeaders.setAccept(acceptTypes);
        requestHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        try {
            return restClient.postForObject(requestHeaders, "/sapi/datasearch/external/data/executeSql", valueMap, Map.class);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw e;
        }
    }

    /**
     * 拼接请求头
     * @return
     */
    public HttpHeaders getHttpHeaders() {
        HttpHeaders requestHeaders = new HttpHeaders();
        String tenantKey = TenantRpcContext.getTenantKey();
        String eteamsId = TenantRpcContext.getEteamsId();
        String employeeId = TenantRpcContext.getEmployeeId();
        if (employeeId != null && !employeeId.isEmpty()) {
            requestHeaders.set("employeeId", employeeId);
        }

        if (tenantKey != null && !tenantKey.isEmpty()) {
            requestHeaders.set("tenantKey", tenantKey);
        }

        if (eteamsId != null && !eteamsId.isEmpty()) {
            requestHeaders.set("eteamsId", eteamsId);
        }
        return requestHeaders;
    }
}

