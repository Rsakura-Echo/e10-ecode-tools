package com.weaver.seconddev.prop;

import com.weaver.framework.client.annotation.WeaverConfigCenter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * dataId：自定义配置文件名称 weaver-sec-service.properties
 * group：配置文件所属分组，配置中心默认DEFAULT_GROUP
 * refresh：是否开启动态刷新，默认为false
 */
@Configuration
@WeaverConfigCenter(sources = {@WeaverConfigCenter.ConfigProperty(dataId = "weaver-sec-service.properties", group = "DEFAULT_GROUP", refresh = "true")})
public class SecConfig {

    @Value("${secondev.key}")
    private String key;

    public String getKey() {
        return key;
    }
}
