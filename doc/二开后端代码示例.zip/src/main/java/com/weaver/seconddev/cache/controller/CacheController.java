package com.weaver.seconddev.cache.controller;

import com.weaver.common.cache.base.BaseCache;
import com.weaver.seconddev.cache.cons.SecDemoModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/seconddev/cache")
public class CacheController {

    @Autowired
    BaseCache baseCache;

    @PostMapping("/add")
    public Object addCache() {
        // 缓存时间可以选择性设置
        return baseCache.set(SecDemoModule.MODULE, SecDemoModule.CACHE_KEY, "cache msg ......", 60 * 60);
    }

    @PostMapping("/del")
    public Object  delCache(){
        return baseCache.del(SecDemoModule.MODULE, SecDemoModule.CACHE_KEY);
    }

    @RequestMapping("/get")
    public Object  getCache(){
        return  baseCache.get(SecDemoModule.MODULE, SecDemoModule.CACHE_KEY);
    }
}
