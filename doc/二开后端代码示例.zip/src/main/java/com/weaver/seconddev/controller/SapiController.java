package com.weaver.seconddev.controller;

import com.weaver.common.base.entity.result.WeaResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/sapi/secondev/workflow/demo")
public class SapiController {

    // /sapi/secondev/workflow/demo/hello
    // 开放平台调用：/openserver/api/secondev/workflow/demo/hello

    @GetMapping("/hello")
    public WeaResult<String> hello(@RequestParam("key") String key, HttpServletRequest request, HttpServletResponse response) {
        // todo

        Map<String, Object> datas = new HashMap<>();
        datas.put("msg", "sapi success");
        return WeaResult.success(key);
    }

    // /sapi/secondev/workflow/demo/hello
    // e10地址/openserver/api/secondev/workflow/demo/hello


}
