package com.weaver.seconddev.mq;

import com.weaver.common.async.bean.AsyncBean;
import com.weaver.common.async.consumer.anno.method.AsyncListener;
import com.weaver.common.async.consumer.bean.listener.AsyncListenerResultBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class Consumer {

    private final Logger log = LoggerFactory.getLogger(Consumer.class);

    @AsyncListener(queues = "secondev_test") //queues是监听的队列名称
    public AsyncListenerResultBean receive(AsyncBean<String> message) {
        AsyncListenerResultBean asyncListenerResultBean = new AsyncListenerResultBean();
        log.info("consumer_" + Thread.currentThread().getId() + " ::: " + message.getMessage());
        asyncListenerResultBean.setStatus(true);
        // sys-secondev.log
        return asyncListenerResultBean;
    }

}
