package com.weaver.seconddev.escheduler;

import com.weaver.common.escheduler.context.ESchedulerJobHelper;
import com.weaver.common.escheduler.handler.annotation.ESchedulerHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class DemoEscheduler {

    private static final Logger log = LoggerFactory.getLogger(DemoEscheduler.class);

    /**
     * value: 业务方法的执行名称
     * cron: cron表达式自定义执行时间
     * @throws Exception
     */
    @ESchedulerHandler(value = "demoJobHandler", cron = "0/10 * * * * ?")
    public void demoJobHandler() throws Exception {
        log.info("demoJobHandler runnint");
        try {
            // todo
            // 获取页面上配置的任务参数
            final String jobParam = ESchedulerJobHelper.getJobParam();

        } catch (Exception e) {
            e.printStackTrace();
            log.error("demoJobHandler runnint error");
        }
        ESchedulerJobHelper.log("ESchedulerHandler, Hello World.");
    }
}
