package com.weaver.seconddev.mq;

import com.weaver.common.async.bean.AsyncBean;
import com.weaver.common.async.producer.client.AsyncClient;
import com.weaver.common.base.entity.result.WeaResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/secondev/mq")
public class Producer {

    @Autowired
    private AsyncClient asyncClient; // 注入消息生产者实例

    @RequestMapping("/test")
    public WeaResult<Boolean> sendMsg() {
        new Thread(() -> {
            String mqQueue = "secondev_test";
            for (int index = 0; index <= 10; index++) {
                //发送消息
                AsyncBean asyncBean = new AsyncBean();
                asyncBean.setQueue(mqQueue);// 消息队列名
                asyncBean.setMessage("test_" + index); // message 可以是 能序列化的对象
                this.asyncClient.send(asyncBean); // 发送消息
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                }
            }
        }).start();

        return WeaResult.success(true);
    }

}
