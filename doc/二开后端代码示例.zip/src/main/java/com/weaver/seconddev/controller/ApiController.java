package com.weaver.seconddev.controller;

import com.google.common.collect.Maps;
import com.weaver.common.authority.annotation.WeaPermission;
import com.weaver.common.base.entity.result.WeaResult;
import com.weaver.common.distribution.genid.IdGenerator;
import com.weaver.common.distribution.lock.DistributionLockInterface;
import com.weaver.ecode.api.dto.FolderDto;
import com.weaver.ecode.api.rpc.EcodeService;
import com.weaver.framework.rpc.annotation.RpcReference;
import com.weaver.seconddev.prop.SecDevProperty;
import com.weaver.teams.domain.user.SimpleEmployee;
import com.weaver.teams.security.context.UserContext;
import com.weaver.teams.security.user.User;
import com.weaver.workflow.common.entity.list.api.publicapi.RequestListInfoPAEntity;
import com.weaver.workflow.list.api.rest.publicapi.WflRequestListRest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping({"/api/secondev/workflow/demo", "/api/secondev/list/demo"})
@WeaPermission(publicPermission = true)
public class ApiController {

    // api 需要用户会话，e10入口地址访问
    // sapi 服务内部通信的接口路由前缀 /sapi/secondev，e10入口地址访问不了
    // 二开服务新接口：/api/secondev
    // 二开严禁随意声明/papi接口！！！
    // 如需发布接口给外部系统调用，请统一声明为/sapi接口并通过开放平台认证调用！！！

    private static final Logger log = LoggerFactory.getLogger(ApiController.class);

    @Autowired
    SecDevProperty secDevProperty;
    @RpcReference(timeout = 10000)
    EcodeService ecodeService;
    @RpcReference(timeout = 2000, group = "workflow")
    WflRequestListRest wflRequestListRest;
    @Autowired
    private DistributionLockInterface distributionLock;

    @GetMapping("/hello")
    //@PostMapping("/post")
    public WeaResult<String> hello(@RequestParam("key") String key) {
        // todo api
        final User currentUser = UserContext.getCurrentUser();
        //final Tenant currentTenant = TenantContext.getCurrentTenant();
        final Long employeeId = currentUser.getEmployeeId();//用户
        final String tenantKey = currentUser.getTenantKey();//租户
        return WeaResult.success(key);
    }

    @RequestMapping("/echo")
    public WeaResult<Map<String, Object>> echo(@RequestParam(value = "param", defaultValue = "") String param) {
        Map<String, Object> res = new HashMap<>();
        res.put("timestamp", System.currentTimeMillis());
        res.put("data", param);
        res.put("moduleName", secDevProperty.getModuleName());
        log.debug("echo running...");
        log.info("params {}", param);
        try {
            // todo
        } catch (Exception e) {
            log.error("echo error", e);
        }
        // 生成分布式id
        final long id = IdGenerator.generate();
        final long[] ids = IdGenerator.generateRangeId(10);
        res.put("id", id);
        res.put("ids", ids);
        return WeaResult.success(res);
    }

    @GetMapping("/prop")
    public WeaResult<String> prop() {
        // todo
        final String moduleName = secDevProperty.getModuleName();
        return WeaResult.success(moduleName);
    }


    @GetMapping("/permission")
    @WeaPermission(publicPermission = true)
    public WeaResult<String> permission(@RequestParam(value = "id", defaultValue = "") String id) {
        // todo
        final String moduleName = secDevProperty.getModuleName();
        return WeaResult.success(moduleName);
    }

    /**
     * 直接调用方法的使用方式
     * @param key
     * @return
     * @throws Exception
     */
    @GetMapping("/lock")
    public WeaResult<Boolean> lock(@RequestParam(value = "key", defaultValue = "") String key) throws Exception {
        int expireTime = 60;
        // **********这里一定要注意，distributionLock.tryLock()方法一定要在try{ }代码块外面**********
        // 可以设置锁的生命周期的API方式
        distributionLock.tryLock(key, expireTime);
        try {
            // todo
        } finally {
            distributionLock.unLock(key);
        }
        return WeaResult.success(Boolean.TRUE);
    }

    @GetMapping("/rpc")
    public WeaResult<Object> rpc(@RequestParam(value = "key", defaultValue = "") String key) throws Exception {
        log.info("key is {}", key);
        final FolderDto query = ecodeService.query(Long.valueOf(key));
        Map<String, Object> res = Maps.newHashMap();
        res.put("ecodeApp", query);
        return WeaResult.success(res);
    }

    @GetMapping("/getRequestListByTabId")
    public WeaResult<List<RequestListInfoPAEntity>> getRequestListByTabId(@RequestParam(value = "tabId", defaultValue = "") int tabId) throws Exception {
        log.info("tabId is {}", tabId);
        try {
            final SimpleEmployee currentUser = UserContext.getCurrentUser();
            final WeaResult<List<RequestListInfoPAEntity>> requestListByTabId = wflRequestListRest.getRequestListByTabId(currentUser, tabId, 1, 10, null);
            if (requestListByTabId.getCode() == 200) {
                requestListByTabId.getData().forEach(k -> {
                    // todo
                    });
            }
            return requestListByTabId;
        } catch (Exception e) {
            log.error("getRequestListByTabId error: {}", e);
        }
        return WeaResult.fail("failed");
    }


}
